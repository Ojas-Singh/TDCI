use pyo3::{prelude::*, types::{PyModule}};
use num::complex::Complex;
#[path = "lib/read_write.rs"]
mod read_write;
pub fn getvariable() -> PyResult<(Vec<Vec<Complex<f64>>>,Vec<Vec<Vec<Vec<Complex<f64>>>>>)> {

    Python::with_gil(|py| {

//         let activators = PyModule::from_code(py, r#"
// def relu(x):
//     import psi4
//     import numpy as np
//     psi4.core.set_output_file('output.dat', False)
//     numpy_memory = 14
//     mol = psi4.geometry("""
//     O
//     symmetry c1
//     """)
//     psi4.set_options({'basis': 'cc-pVDZ', 'scf_type': 'pk', 'e_convergence': 1e-8, 'd_convergence': 1e-8})
//     scf_e, wfn = psi4.energy('SCF', return_wfn=True)
//     C = wfn.Ca()
//     mints = psi4.core.MintsHelper(wfn.basisset())
//     H = np.asarray(mints.ao_kinetic()) + np.asarray(mints.ao_potential())
//     MO = np.asarray(mints.mo_spin_eri(C, C))
//     Vee = np.asarray(mints.mo_eri(C,C,C,C))
//     H = np.einsum('uj,vi,uv', C, C, H)
//     Hone = H.copy()
//     H = np.repeat(H, 2, axis=0)
//     H = np.repeat(H, 2, axis=1)
//     spin_ind = np.arange(H.shape[0], dtype=np.int) % 2
//     H *= (spin_ind.reshape(-1, 1) == spin_ind)
//     Hr=[]
//     for i in Hone:
//         for j in i:
//             Hr.append(j)
//     Vr=[]
//     for i in Vee:
//         for j in i:
//             for k in j:
//                 for l in k:
//                     Vr.append(l)
//     return H,MO

//     "#, "activators.py", "activators")?;

let activators = PyModule::from_code(py, &read_write::pycode(), "code.py", "activators")?;
        let (H,V):(Vec<Vec<f64>>,Vec<Vec<Vec<Vec<f64>>>>) = activators.getattr("run")?.call1((1.0,))?.extract()?;
        let mut Hcom:Vec<Vec<Complex<f64>>> = Vec::new();
        let mut Vcom:Vec<Vec<Vec<Vec<Complex<f64>>>>> = Vec::new();
        for i in H {
            let mut t : Vec<Complex<f64>>= Vec::new();
            for j in i {
                t.push(Complex::new(j,0.0));
            }
            Hcom.push(t)
        }
        for i in V {
            let mut t2 : Vec<Vec<Vec<Complex<f64>>>>= Vec::new();
            for j in i {
                let mut t3 : Vec<Vec<Complex<f64>>>= Vec::new();
                for k in j {
                    let mut t4 : Vec<Complex<f64>>= Vec::new();
                    for l in k {
                        t4.push(Complex::new(l,0.0))
                    }
                    t3.push(t4)
                }
                t2.push(t3)
            }
            Vcom.push(t2)
        }


        Ok((Hcom,Vcom))
    })
}

